(async function () {
    const result = await fetch("a.php");
    const result2 = await fetch("b.php?data="+result);
    console.log(result+result2);
})();

//promise
function fetch(url){
    return new Promise((resolve,reject)=>{
        $.ajax(url).then(function(){
            resolve("成功")
        }).error(function(){
            reject("失败");
        })
    })
}
//Promise、generator、yield、async、await 到底是什么关系？
