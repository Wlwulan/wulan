function Car(color) {
    console.count();
    this.color = color;
    //逻辑处理的非常复杂
}
Car.prototype.mail = function () {
    console.log(this.color);
}
function BMW(color) {
    //父类的构造函数 参数
    Car.call(this, color);
}
// BMW.prototype = new Car();
var _proto = Object.create(Car.prototype);
_proto.constructor = BMW;
BMW.prototype = _proto;
BMW.prototype.test = function () {}
var car = new BMW("red");
console.log(car);
//编程OOP AOP FP
class YDCar{
    constructor(color){
        this.color = color;
    }
    mail(){
        console.log(this.color);
    }
}
YDCar.prototype.mail = function(){
    console.log("xxxxxxxx");
}
const ydcar = new YDCar("white");
ydcar.mail();
// class YDBWM extends YDCar{
//     constructor(color){
//         super(color);
//     }
// }
// const bwm = new YDBWM("white");
// bwm.mail();

// class Test{
//     #a;
//     static fn(){
//     }
//     constructor(){
//         this.#a = 1;
//     }
// }
// Test.fn();